
const customerData = () => {
    const Data = [
        {
            CustomerName: 'xyz',
            RoomName: 'AC',
            Date: '19/4/23',
            startTime: '6:30 AM',
            endTime: '08:00PM'
        },
        {
            CustomerName: 'YYY',
            RoomName: 'NON-AC',
            Date: '18/4/23',
            startTime: '6:30 AM',
            endTime: '08:00PM'
        },
        {
            CustomerName: 'ZZZ',
            RoomName: 'Delux',
            Date: '18/4/23',
            startTime: '6:30 AM',
            endTime: '08:00PM'
        }
    ]
    return Data;
}


module.exports = customerData;